import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { ClerkProvider } from '@clerk/clerk-react';

const PUBLISHABLE_KEY = (import.meta as any).env.VITE_CLERK_PUBLISHABLE_KEY;

if (!PUBLISHABLE_KEY) {
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <div className="min-h-screen flex items-center justify-center bg-[#0D001A] text-white p-6 font-sans">
        <div className="max-w-md w-full bg-slate-900 border border-violet-500/20 p-8 rounded-2xl shadow-2xl text-center space-y-6">
          <div className="w-16 h-16 bg-violet-600/10 border border-violet-500/30 rounded-full flex items-center justify-center mx-auto text-violet-400">
            👑
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-display font-extrabold text-white">Clerk Auth Setup Required</h2>
            <p className="text-sm text-slate-400">
              Please provide your Clerk Publishable Key to activate secure user authentication.
            </p>
          </div>
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl text-left text-xs font-mono text-slate-300 space-y-2">
            <p className="font-bold text-violet-400">How to Setup / طريقة الإعداد:</p>
            <ol className="list-decimal pl-4 space-y-1">
              <li>Copy your <span className="text-white">Publishable Key</span> from Clerk Dashboard.</li>
              <li>Open the <span className="text-white">Secrets / Settings menu</span> in the AI Studio UI.</li>
              <li>Add a new secret: <span className="text-white">VITE_CLERK_PUBLISHABLE_KEY</span>.</li>
              <li>Or add it inside your local <span className="text-white">.env</span> file if working offline.</li>
            </ol>
          </div>
          <p className="text-xs text-slate-500 font-light">
            Once configured, reload this page to access your secure enterprise chatbot platform!
          </p>
        </div>
      </div>
    </StrictMode>
  );
} else {
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <ClerkProvider publishableKey={PUBLISHABLE_KEY}>
        <App />
      </ClerkProvider>
    </StrictMode>,
  );
}

